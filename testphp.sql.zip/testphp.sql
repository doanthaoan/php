-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2020 at 06:27 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
CREATE TABLE IF NOT EXISTS `answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Truncate table before insert `answer`
--

TRUNCATE TABLE `answer`;
--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`id`, `qid`, `cid`) VALUES
(1, 1, 4),
(2, 2, 5),
(3, 3, 11);

-- --------------------------------------------------------

--
-- Table structure for table `choice`
--

DROP TABLE IF EXISTS `choice`;
CREATE TABLE IF NOT EXISTS `choice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

--
-- Truncate table before insert `choice`
--

TRUNCATE TABLE `choice`;
--
-- Dumping data for table `choice`
--

INSERT INTO `choice` (`id`, `qid`, `text`) VALUES
(1, 1, '$a = array()'),
(2, 1, 'a = [1,2,3,4,5];'),
(3, 1, 'a = array(1,2,3,4);'),
(4, 1, '$a = [1,2,3,4,5];'),
(5, 2, 'function functionName($parameter) { <br>\r\n // your code goes here <br>\r\n}'),
(6, 2, 'function $functionName($parameter) {<br>\r\n // your code goes here <br>\r\n}'),
(7, 2, 'function functionName(<br>\r\n// your code goes here<br>\r\n)'),
(8, 2, '$functionName($parameter) {<br>\r\n // your code goes here<br>\r\n}'),
(9, 3, 'You identify variables with a leading dollar sign ($) in front of the variable name.'),
(10, 3, 'You must start a variable name with either a letter or an underscore\r\ncharacter (_)'),
(11, 3, 'PHP variable names are NOT case-sensitive.'),
(12, 3, 'Variable name can contain only letters, numbers, and underscores (the variable name can’t contain any spaces or other special characters).'),
(13, 1, '$a = {1,2,3,4,5}');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `point` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

--
-- Truncate table before insert `question`
--

TRUNCATE TABLE `question`;
--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `text`, `point`) VALUES
(1, 'question 1: what is the correct way to define an array variable?', 1),
(2, 'how can we define a function?', 2),
(3, 'What is NOT correct about variable?', 2),
(4, 'What is NOT correct about PHP?', 1),
(5, 'How can we display an array type & values?', 1),
(6, 'What options is wrong about loop functions?', 1),
(7, 'There is an array: <br>\r\n$a = [\"a\",\"b\",\"c\",\"d\",\"e\"]; <br>\r\nHow can we display the \"c\" character in that array?', 1);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
CREATE TABLE IF NOT EXISTS `result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) NOT NULL,
  `scores` int(11) NOT NULL,
  `tscores` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Truncate table before insert `result`
--

TRUNCATE TABLE `result`;
-- --------------------------------------------------------

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
CREATE TABLE IF NOT EXISTS `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(11) NOT NULL,
  `questions` text NOT NULL,
  `scores` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Truncate table before insert `test`
--

TRUNCATE TABLE `test`;
--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `subject`, `questions`, `scores`) VALUES
(1, 'PHP basic 0', '1,2,3,4,5,6', 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
